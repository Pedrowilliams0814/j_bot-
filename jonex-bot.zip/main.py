
import os
import smtplib
from flask import Flask
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from bs4 import BeautifulSoup
import requests

BOT_TOKEN = "7874767939:AAGiZb42yCSlWeC4JcwWiFmNE4nr-UPEano"
GMAIL_ADDRESS = "pedrowilliams0814@gmail.com"
APP_PASSWORD = "cfuj bqbh xzvt wgqk"
OPENAI_API_KEY = "your_openai_api_key_here"  # <-- Insert your OpenAI key here

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Hello! I am Jonex — your email marketing assistant.")

async def extract_emails(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❗ Please provide a URL. Example: /extract https://example.com")
        return

    url = context.args[0]
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, "html.parser")
        text = soup.get_text()
        emails = list(set([word for word in text.split() if "@" in word and "." in word]))
        if emails:
            with open("emails.txt", "w") as f:
                for email in emails:
                    f.write(email + "\n")
            await update.message.reply_text(f"✅ Found {len(emails)} emails and saved to emails.txt")
        else:
            await update.message.reply_text("❌ No emails found on that page.")
    except Exception as e:
        await update.message.reply_text(f"Error: {e}")

async def send_emails(update: Update, context: ContextTypes.DEFAULT_TYPE):
    subject = "Boost Your Business Reputation ⭐"
    body = "Hello! We offer 5-star review services to help grow your brand. Let's work together. – Jonex ⭐"

    try:
        with open("emails.txt", "r") as f:
            recipients = [line.strip() for line in f.readlines()]

        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(GMAIL_ADDRESS, APP_PASSWORD)

        for email in recipients:
            msg = MIMEMultipart()
            msg["From"] = GMAIL_ADDRESS
            msg["To"] = email
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))
            server.sendmail(GMAIL_ADDRESS, email, msg.as_string())

        server.quit()
        await update.message.reply_text("✅ Marketing emails sent successfully!")
    except Exception as e:
        await update.message.reply_text(f"❌ Failed to send emails: {e}")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("extract", extract_emails))
app.add_handler(CommandHandler("send", send_emails))

def run_flask():
    server = Flask('')

    @server.route('/')
    def home():
        return "Jonex Bot is Live!"

    server.run(host='0.0.0.0', port=8080)

import threading
threading.Thread(target=run_flask).start()

app.run_polling()
